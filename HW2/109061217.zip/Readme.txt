Compile comand:
1. Put AES.cpp and GF256.h under same folder
2. g++ AES.cpp -o AES

執行後會依序要求輸入Plaintext和Key，請先輸入完Plaintext後按下enter再輸入Key，再按一次enter即可看到各個round的結果。