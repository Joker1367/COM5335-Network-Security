Compile comand:
1. Put Rabin.cpp and BigNumber.h under same folder
2. g++ Rabin.cpp -o Rabin

執行後首先是產生256 bit prime number的部分，大概需要等15-20秒左右才會看到結果。
接下來是Robin Encryption，按照要求輸入p, q, Plaintext，各個輸入之間要按enter，即可看到Encryption的結果。
接下來是Robin Decryption，注意事項與Rabin Encryption相同，輸入完成後大概需要等1、2秒才會看到結果。