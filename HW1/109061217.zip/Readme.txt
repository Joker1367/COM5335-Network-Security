Compile comand:
1. Put BigNumber.cpp and BigNumber.h under same folder
2. g++ BigNumber.cpp -o BigNumber